package ge.ibsu.demo.entities;

import jakarta.persistence.*;
import org.springframework.data.annotation.Id;

    @Entity
    @Table(name = "city")
    public class City {

        @jakarta.persistence.Id
        @Id
        @SequenceGenerator(name = "city_city_id_seq", sequenceName = "city_city_id_seq", allocationSize = 1)
        @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "city_city_id_seq")
        @Column(name="city_id")
        private Long id;
        @Column(name="city_fields")
        private String fields;

        @ManyToOne(fetch = FetchType.LAZY)
        @JoinColumn(name = "address_id")
        private Address address;
}
