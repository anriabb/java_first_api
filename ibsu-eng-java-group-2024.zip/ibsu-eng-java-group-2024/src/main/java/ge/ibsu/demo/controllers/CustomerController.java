package ge.ibsu.demo.controllers;
import ge.ibsu.demo.dto.AddCustomer;
import ge.ibsu.demo.entities.Customer;
import ge.ibsu.demo.services.CustomerService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping
public class CustomerController {
    private final CustomerService customerService;
    public CustomerController(CustomerService customerService) {
        this.customerService = customerService;
    }
    @RequestMapping(value = "/{id}", method = RequestMethod.POST, produces = {"application/json"})
    public Customer getOne(@RequestBody AddCustomer addCustomer, @PathVariable Long id) {
        return customerService.addEditCustomer(addCustomer, null);
    }
    @RequestMapping(value = "/add", method = RequestMethod.PUT, produces = {"application/json"})
    public Customer add(@RequestBody AddCustomer addCustomer, @PathVariable Long id) {
        return customerService.addEditCustomer(addCustomer, id);
    }
}
